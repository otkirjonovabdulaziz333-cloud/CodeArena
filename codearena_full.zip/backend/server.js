const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');
const { v4: uuidv4 } = require('uuid');
const fetch = require('node-fetch');

const SECRET = process.env.SECRET || 'change_this_to_a_strong_secret';
const PORT = process.env.PORT || 4000;
const JUDGE_URL = process.env.JUDGE_URL || 'http://judge:5000/run';

const app = express();
app.use(cors());
app.use(bodyParser.json());

let db;
(async () => {
  db = await open({ filename: './codearena.db', driver: sqlite3.Database });
  await db.exec(`
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE,
      password_hash TEXT,
      display_name TEXT,
      role TEXT DEFAULT 'user'
    );
    CREATE TABLE IF NOT EXISTS problems (
      id TEXT PRIMARY KEY,
      title TEXT,
      statement TEXT,
      input_example TEXT,
      output_example TEXT,
      author_id TEXT,
      FOREIGN KEY(author_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS contests (
      id TEXT PRIMARY KEY,
      title TEXT,
      description TEXT,
      owner_id TEXT,
      start_ts INTEGER,
      end_ts INTEGER,
      FOREIGN KEY(owner_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS contest_problems (
      id TEXT PRIMARY KEY,
      contest_id TEXT,
      problem_id TEXT,
      FOREIGN KEY(contest_id) REFERENCES contests(id),
      FOREIGN KEY(problem_id) REFERENCES problems(id)
    );
    CREATE TABLE IF NOT EXISTS submissions (
      id TEXT PRIMARY KEY,
      problem_id TEXT,
      user_id TEXT,
      language TEXT,
      code TEXT,
      result TEXT,
      stdout TEXT,
      stderr TEXT,
      created_at INTEGER,
      FOREIGN KEY(problem_id) REFERENCES problems(id),
      FOREIGN KEY(user_id) REFERENCES users(id)
    );
  `);

  const owners = await db.all(`SELECT * FROM users WHERE role = 'owner'`);
  if (owners.length === 0) {
    const id = uuidv4();
    const pw = process.env.DEFAULT_OWNER_PW || 'owner1234';
    const hash = await bcrypt.hash(pw, 10);
    await db.run(`INSERT INTO users (id, username, password_hash, display_name, role) VALUES (?, ?, ?, ?, ?)`, id, 'owner', hash, 'Owner', 'owner');
    console.log('Default owner created -> username: owner password:', pw);
  }
})();

function sign(user) {
  return jwt.sign({ id: user.id, username: user.username, role: user.role }, SECRET, { expiresIn: '7d' });
}

async function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'No token' });
  const token = auth.split(' ')[1];
  try {
    const payload = jwt.verify(token, SECRET);
    const user = await db.get('SELECT id, username, role, display_name FROM users WHERE id = ?', payload.id);
    if (!user) return res.status(401).json({ error: 'Invalid token' });
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// Auth
app.post('/api/register', async (req, res) => {
  try {
    const { username, password, display_name } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'username and password required' });
    const exists = await db.get('SELECT id FROM users WHERE username = ?', username);
    if (exists) return res.status(400).json({ error: 'username exists' });
    const hash = await bcrypt.hash(password, 10);
    const id = uuidv4();
    await db.run('INSERT INTO users (id, username, password_hash, display_name, role) VALUES (?, ?, ?, ?, ?)', id, username, hash, display_name || username, 'user');
    res.json({ success: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'server error' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await db.get('SELECT * FROM users WHERE username = ?', username);
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(400).json({ error: 'Invalid credentials' });
    const token = sign(user);
    res.json({ token, user: { id: user.id, username: user.username, display_name: user.display_name, role: user.role } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'server error' });
  }
});

// Promote user to problemsetter (owner only)
app.post('/api/promote', authMiddleware, async (req, res) => {
  if (req.user.role !== 'owner') return res.status(403).json({ error: 'Only owner can promote' });
  const { username } = req.body;
  const u = await db.get('SELECT * FROM users WHERE username = ?', username);
  if (!u) return res.status(404).json({ error: 'User not found' });
  await db.run('UPDATE users SET role = ? WHERE id = ?', 'problemsetter', u.id);
  res.json({ success: true, promoted: u.username });
});

// Users list / search
app.get('/api/users', authMiddleware, async (req, res) => {
  const q = (req.query.q || '').trim();
  let rows;
  if (q) {
    rows = await db.all('SELECT id, username, display_name, role FROM users WHERE username LIKE ? OR display_name LIKE ? LIMIT 50', `%${q}%`, `%${q}%`);
  } else {
    rows = await db.all('SELECT id, username, display_name, role FROM users LIMIT 50');
  }
  res.json(rows);
});

// Problems
app.post('/api/problems', authMiddleware, async (req, res) => {
  if (!['owner','problemsetter'].includes(req.user.role)) return res.status(403).json({ error: 'Only owner/problemsetter can create problems' });
  const { title, statement, input_example, output_example } = req.body;
  if (!title || !statement) return res.status(400).json({ error: 'title and statement required' });
  const id = uuidv4();
  await db.run('INSERT INTO problems (id, title, statement, input_example, output_example, author_id) VALUES (?, ?, ?, ?, ?, ?)', id, title, statement, input_example || '', output_example || '', req.user.id);
  res.json({ success: true, id });
});

app.get('/api/problems', authMiddleware, async (req, res) => {
  const rows = await db.all('SELECT p.id, p.title, p.statement, p.input_example, p.output_example, u.username as author FROM problems p LEFT JOIN users u ON p.author_id = u.id LIMIT 200');
  res.json(rows);
});

app.get('/api/problems/:id', authMiddleware, async (req, res) => {
  const p = await db.get('SELECT p.*, u.username as author FROM problems p LEFT JOIN users u ON p.author_id = u.id WHERE p.id = ?', req.params.id);
  if (!p) return res.status(404).json({ error: 'Not found' });
  res.json(p);
});

// Contests
app.post('/api/contests', authMiddleware, async (req, res) => {
  if (!['owner','problemsetter'].includes(req.user.role)) return res.status(403).json({ error: 'Not allowed' });
  const { title, description, start_ts, end_ts } = req.body;
  if (!title) return res.status(400).json({ error: 'title required' });
  const id = uuidv4();
  await db.run('INSERT INTO contests (id, title, description, owner_id, start_ts, end_ts) VALUES (?, ?, ?, ?, ?, ?)', id, title, description || '', req.user.id, start_ts || null, end_ts || null);
  res.json({ success: true, id });
});

app.get('/api/contests', authMiddleware, async (req, res) => {
  const rows = await db.all('SELECT c.*, u.username as owner_name FROM contests c LEFT JOIN users u ON c.owner_id = u.id ORDER BY start_ts DESC LIMIT 100');
  res.json(rows);
});

app.post('/api/contests/:contestId/problems', authMiddleware, async (req, res) => {
  if (!['owner','problemsetter'].includes(req.user.role)) return res.status(403).json({ error: 'Not allowed' });
  const { problemId } = req.body;
  const cid = req.params.contestId;
  const cpId = uuidv4();
  await db.run('INSERT INTO contest_problems (id, contest_id, problem_id) VALUES (?, ?, ?)', cpId, cid, problemId);
  res.json({ success: true });
});

// Submissions -> send to judge service
app.post('/api/submissions', authMiddleware, async (req, res) => {
  try {
    const { problemId, language, code } = req.body;
    if (!problemId || !language || !code) return res.status(400).json({ error: 'problemId, language, code required' });
    const problem = await db.get('SELECT * FROM problems WHERE id = ?', problemId);
    if (!problem) return res.status(404).json({ error: 'Problem not found' });
    const submissionId = uuidv4();
    const now = Date.now();
    await db.run('INSERT INTO submissions (id, problem_id, user_id, language, code, result, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)', submissionId, problemId, req.user.id, language, code, 'PENDING', now);

    // Call judge service
    const payload = { code, language, input: problem.input_example || '', expected: problem.output_example || '' };
    const r = await fetch(JUDGE_URL, { method: 'POST', body: JSON.stringify(payload), headers: { 'Content-Type': 'application/json' } });
    const jr = await r.json();
    await db.run('UPDATE submissions SET result = ?, stdout = ?, stderr = ? WHERE id = ?', jr.result || 'ERROR', jr.stdout || '', jr.stderr || '', submissionId);
    res.json({ id: submissionId, result: jr.result, stdout: jr.stdout || '', stderr: jr.stderr || '' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'server error' });
  }
});

app.get('/api/submissions', authMiddleware, async (req, res) => {
  const rows = await db.all('SELECT s.*, p.title as problem_title FROM submissions s LEFT JOIN problems p ON s.problem_id = p.id WHERE s.user_id = ? ORDER BY created_at DESC LIMIT 200', req.user.id);
  res.json(rows);
});

app.get('/api/status', (req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log('Backend listening on', PORT);
});
