from flask import Flask, request, jsonify
import subprocess, tempfile, os, uuid, resource, signal, json, shutil

app = Flask(__name__)

# Limits (tunable)
CPU_TIME = 2  # seconds
MEM_BYTES = 150 * 1024 * 1024  # 150 MB

def limit_resources():
    # Set CPU time (seconds)
    resource.setrlimit(resource.RLIMIT_CPU, (CPU_TIME, CPU_TIME))
    # Set address space / memory
    resource.setrlimit(resource.RLIMIT_AS, (MEM_BYTES, MEM_BYTES))
    # Prevent creating subprocesses
    resource.setrlimit(resource.RLIMIT_NPROC, (10, 10))

@app.route('/run', methods=['POST'])
def run():
    data = request.get_json(force=True)
    code = data.get('code', 'print()')
    language = data.get('language', 'python')
    stdin = data.get('input', '')
    expected = data.get('expected', '').strip()

    if language != 'python':
        return jsonify({ 'result': 'LANG_NOT_SUPPORTED' }), 400

    tmpdir = '/tmp/runner'
    os.makedirs(tmpdir, exist_ok=True)
    fname = os.path.join(tmpdir, f'{uuid.uuid4()}.py')
    with open(fname, 'w') as f:
        f.write(code)

    try:
        # Run with resource limits using subprocess and preexec_fn
        proc = subprocess.Popen(['python3', fname], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, preexec_fn=limit_resources)
        try:
            stdout, stderr = proc.communicate(input=stdin.encode(), timeout=CPU_TIME+1)
        except subprocess.TimeoutExpired:
            proc.kill()
            return jsonify({'result':'TIME_LIMIT'})
        out = stdout.decode().strip()
        err = stderr.decode().strip()
        if err:
            return jsonify({'result':'RUNTIME_ERROR', 'stderr': err})
        if out == expected:
            return jsonify({'result':'OK', 'stdout': out})
        else:
            return jsonify({'result':'WRONG_ANSWER', 'stdout': out, 'expected': expected})
    except Exception as e:
        return jsonify({'result':'ERROR', 'error': str(e)})
    finally:
        try:
            os.remove(fname)
        except:
            pass

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
