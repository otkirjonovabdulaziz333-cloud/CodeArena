# CodeArena - Full (Docker) prototype

This repository contains a fuller CodeArena prototype with:
- Backend: Node.js + Express + SQLite + JWT
- Frontend: static HTML + JS (simple demo)
- Judge: Flask service that runs Python code with resource limits
- Docker Compose to run everything locally

IMPORTANT:
- The judge runs user code inside the judge container with resource limits (RLIMIT). This is for testing only. For production you must use stronger isolation (Docker-in-Docker, gVisor, Firecracker, or dedicated judge runners), network/FS restrictions and proper monitoring.

## Run locally
1. unzip and cd into the project
2. Build and start:

```bash
docker-compose up --build
```

Services:
- Frontend: http://localhost:3000
- Backend API: http://localhost:4000
- Judge: http://localhost:5000 (internal)

Default owner is created with username `owner` and password printed in backend logs or set via env DEFAULT_OWNER_PW.

## Notes
- Change SECRET env var before deploying publicly.
- Use PostgreSQL for production instead of SQLite.
- Add HTTPS, rate limiting, and stronger sandboxing for judge.
